import StudentForm from './components/StudentForm';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <StudentForm />
    </div>
  );
}

export default App;
